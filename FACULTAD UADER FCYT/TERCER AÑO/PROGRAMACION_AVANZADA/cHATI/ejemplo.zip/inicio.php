<!DOCTYPE html>
<html lang="es">
<?php require_once 'includes/head.php';?>
<?php require_once 'includes/menu.php'; ?>
    <br>
    
        <h4 class="text-center">Sistema Recursos Humanos</h4>
        <div class="row justify-content-lg-center">
            <div class="col col-lg-auto">
                <a href="inicio.php" type="button" class="btn btn-info">Inicio</a>
            </div>
            <div class="col col-lg-auto">
                <a href="formPersonas.php" type="button" class="btn btn-info">Formulario de Personas</a>
            </div>
            <div class="col col-lg-auto">
                <a href="listadoPersonas.php" type="button" class="btn btn-info">Listado de Personas</a>
            </div>
        </div>

<?php require_once 'includes/footer.php'; ?>

